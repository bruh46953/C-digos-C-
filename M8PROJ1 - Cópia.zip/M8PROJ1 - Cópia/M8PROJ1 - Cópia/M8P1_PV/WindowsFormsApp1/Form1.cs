﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton5.Checked)
            {
               
                this.BackColor = Color.LightBlue;
            }
            else
            {
              
                this.BackColor = SystemColors.Control;
            }
        }

        private void radioButton8_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {
                      
        }
        //Entrada do programa
        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("THE BEST PROGRAM OF THE WORLD!!");
        }

        private void lblResultado_Click(object sender, EventArgs e)
        {

        }

        private void rdoTotSemIva_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void rdoTotComIva_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void rdoDolares_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void rdoSair_CheckedChanged(object sender, EventArgs e)
        {
           
        }
        //Botão ativar limpar
        private void rdoAtivar_CheckedChanged(object sender, EventArgs e)
        {
            btnLimpar.Enabled = true;
        }
        //Botão desativar limapr
        private void rdoDesativar_CheckedChanged(object sender, EventArgs e)
        {
            btnLimpar.Enabled = false;
        }
        //Botão limpar
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtQuantidade.Clear();
            txtPreco.Clear();

            lblResultado.Text = "";

            txtQuantidade.Focus();
        }
        //Total sem IVA
        private void BtnSemIva_Click(object sender, EventArgs e)
        {
            int Quantidade;

            Quantidade = int.Parse(txtQuantidade.Text);
            decimal Preco = decimal.Parse(txtPreco.Text);

            decimal Total = Quantidade * Preco;

            lblResultado.Text = Total.ToString("C2");
        }
        //Total com IVA
        private void BtnComIva_Click(object sender, EventArgs e)
        {
            int Quantidade;

            Quantidade = int.Parse(txtQuantidade.Text);
            decimal Preco = decimal.Parse(txtPreco.Text);

            decimal TotalSIVA = Quantidade * Preco;

            decimal TotalCIVA = TotalSIVA * 1.23m;

            lblResultado.Text = TotalCIVA.ToString("0.00") + " €";
        }
        //Total sem IVA em doláres
        private void BtnSemIvaDolares_Click(object sender, EventArgs e)
        {
            int Quantidade;

            Quantidade = int.Parse(txtQuantidade.Text);
            decimal Preco = decimal.Parse(txtPreco.Text);

            decimal Total = (Quantidade * Preco) + 1.08m;

            lblResultado.Text = Total.ToString("0.00") + " $";
        }
        //Botão sair
        private void BtnSair_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bruhh!!");
            Application.Exit();
        }

        private void txtQuantidade_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPreco_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
