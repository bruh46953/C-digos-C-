﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtQuantidade = new System.Windows.Forms.TextBox();
            this.txtPreco = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblResultado = new System.Windows.Forms.Label();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdoLocalização = new System.Windows.Forms.RadioButton();
            this.rdoDesativar = new System.Windows.Forms.RadioButton();
            this.rdoAtivar = new System.Windows.Forms.RadioButton();
            this.rdoLegenda = new System.Windows.Forms.RadioButton();
            this.rdoFundo = new System.Windows.Forms.RadioButton();
            this.BtnSemIva = new System.Windows.Forms.Button();
            this.BtnComIva = new System.Windows.Forms.Button();
            this.BtnSemIvaDolares = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.BackColor = System.Drawing.Color.IndianRed;
            this.lblTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblTitulo.Location = new System.Drawing.Point(0, 0);
            this.lblTitulo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(398, 24);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "Preço de venda";
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.IndianRed;
            this.label1.Location = new System.Drawing.Point(8, 47);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Quantidade:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.IndianRed;
            this.label2.Location = new System.Drawing.Point(219, 47);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Preço unitário:";
            // 
            // txtQuantidade
            // 
            this.txtQuantidade.Location = new System.Drawing.Point(76, 45);
            this.txtQuantidade.Margin = new System.Windows.Forms.Padding(2);
            this.txtQuantidade.Name = "txtQuantidade";
            this.txtQuantidade.Size = new System.Drawing.Size(90, 20);
            this.txtQuantidade.TabIndex = 1;
            this.txtQuantidade.TextChanged += new System.EventHandler(this.txtQuantidade_TextChanged);
            // 
            // txtPreco
            // 
            this.txtPreco.Location = new System.Drawing.Point(296, 45);
            this.txtPreco.Margin = new System.Windows.Forms.Padding(2);
            this.txtPreco.Name = "txtPreco";
            this.txtPreco.Size = new System.Drawing.Size(90, 20);
            this.txtPreco.TabIndex = 2;
            this.txtPreco.TextChanged += new System.EventHandler(this.txtPreco_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.IndianRed;
            this.label3.Location = new System.Drawing.Point(180, 72);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Total";
            // 
            // lblResultado
            // 
            this.lblResultado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResultado.Location = new System.Drawing.Point(16, 89);
            this.lblResultado.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(369, 26);
            this.lblResultado.TabIndex = 3;
            this.lblResultado.Click += new System.EventHandler(this.lblResultado_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.ForeColor = System.Drawing.Color.IndianRed;
            this.btnLimpar.Location = new System.Drawing.Point(16, 129);
            this.btnLimpar.Margin = new System.Windows.Forms.Padding(2);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(368, 23);
            this.btnLimpar.TabIndex = 4;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdoLocalização);
            this.groupBox1.Controls.Add(this.rdoDesativar);
            this.groupBox1.Controls.Add(this.rdoAtivar);
            this.groupBox1.Controls.Add(this.rdoLegenda);
            this.groupBox1.Controls.Add(this.rdoFundo);
            this.groupBox1.Location = new System.Drawing.Point(24, 171);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(208, 146);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Personalização";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // rdoLocalização
            // 
            this.rdoLocalização.AutoSize = true;
            this.rdoLocalização.Location = new System.Drawing.Point(12, 71);
            this.rdoLocalização.Margin = new System.Windows.Forms.Padding(2);
            this.rdoLocalização.Name = "rdoLocalização";
            this.rdoLocalização.Size = new System.Drawing.Size(158, 17);
            this.rdoLocalização.TabIndex = 1;
            this.rdoLocalização.TabStop = true;
            this.rdoLocalização.Text = "Alterar posição do formulário";
            this.rdoLocalização.UseVisualStyleBackColor = true;
            this.rdoLocalização.CheckedChanged += new System.EventHandler(this.radioButton8_CheckedChanged);
            // 
            // rdoDesativar
            // 
            this.rdoDesativar.AutoSize = true;
            this.rdoDesativar.Location = new System.Drawing.Point(12, 120);
            this.rdoDesativar.Margin = new System.Windows.Forms.Padding(2);
            this.rdoDesativar.Name = "rdoDesativar";
            this.rdoDesativar.Size = new System.Drawing.Size(153, 17);
            this.rdoDesativar.TabIndex = 1;
            this.rdoDesativar.TabStop = true;
            this.rdoDesativar.Text = "Desativar o botão \"Limpar\"";
            this.rdoDesativar.UseVisualStyleBackColor = true;
            this.rdoDesativar.CheckedChanged += new System.EventHandler(this.rdoDesativar_CheckedChanged);
            // 
            // rdoAtivar
            // 
            this.rdoAtivar.AutoSize = true;
            this.rdoAtivar.Location = new System.Drawing.Point(12, 101);
            this.rdoAtivar.Margin = new System.Windows.Forms.Padding(2);
            this.rdoAtivar.Name = "rdoAtivar";
            this.rdoAtivar.Size = new System.Drawing.Size(126, 17);
            this.rdoAtivar.TabIndex = 1;
            this.rdoAtivar.TabStop = true;
            this.rdoAtivar.Text = "Ativar botão \"Limpar\"";
            this.rdoAtivar.UseVisualStyleBackColor = true;
            this.rdoAtivar.CheckedChanged += new System.EventHandler(this.rdoAtivar_CheckedChanged);
            // 
            // rdoLegenda
            // 
            this.rdoLegenda.AutoSize = true;
            this.rdoLegenda.Location = new System.Drawing.Point(12, 46);
            this.rdoLegenda.Margin = new System.Windows.Forms.Padding(2);
            this.rdoLegenda.Name = "rdoLegenda";
            this.rdoLegenda.Size = new System.Drawing.Size(159, 17);
            this.rdoLegenda.TabIndex = 1;
            this.rdoLegenda.TabStop = true;
            this.rdoLegenda.Text = "Alterar legenda do formulário";
            this.rdoLegenda.UseVisualStyleBackColor = true;
            this.rdoLegenda.CheckedChanged += new System.EventHandler(this.radioButton6_CheckedChanged);
            // 
            // rdoFundo
            // 
            this.rdoFundo.AutoSize = true;
            this.rdoFundo.Location = new System.Drawing.Point(12, 21);
            this.rdoFundo.Margin = new System.Windows.Forms.Padding(2);
            this.rdoFundo.Name = "rdoFundo";
            this.rdoFundo.Size = new System.Drawing.Size(156, 17);
            this.rdoFundo.TabIndex = 0;
            this.rdoFundo.TabStop = true;
            this.rdoFundo.Text = "Alterar cor de fundo do form";
            this.rdoFundo.UseVisualStyleBackColor = true;
            this.rdoFundo.CheckedChanged += new System.EventHandler(this.radioButton5_CheckedChanged);
            // 
            // BtnSemIva
            // 
            this.BtnSemIva.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.BtnSemIva.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BtnSemIva.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnSemIva.Location = new System.Drawing.Point(249, 181);
            this.BtnSemIva.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.BtnSemIva.Name = "BtnSemIva";
            this.BtnSemIva.Size = new System.Drawing.Size(134, 25);
            this.BtnSemIva.TabIndex = 6;
            this.BtnSemIva.Text = "Total s/ IVA";
            this.BtnSemIva.UseVisualStyleBackColor = true;
            this.BtnSemIva.Click += new System.EventHandler(this.BtnSemIva_Click);
            // 
            // BtnComIva
            // 
            this.BtnComIva.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.BtnComIva.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BtnComIva.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnComIva.Location = new System.Drawing.Point(250, 211);
            this.BtnComIva.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.BtnComIva.Name = "BtnComIva";
            this.BtnComIva.Size = new System.Drawing.Size(134, 25);
            this.BtnComIva.TabIndex = 7;
            this.BtnComIva.Text = "Total c/ IVA";
            this.BtnComIva.UseVisualStyleBackColor = true;
            this.BtnComIva.Click += new System.EventHandler(this.BtnComIva_Click);
            // 
            // BtnSemIvaDolares
            // 
            this.BtnSemIvaDolares.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.BtnSemIvaDolares.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BtnSemIvaDolares.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnSemIvaDolares.Location = new System.Drawing.Point(250, 241);
            this.BtnSemIvaDolares.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.BtnSemIvaDolares.Name = "BtnSemIvaDolares";
            this.BtnSemIvaDolares.Size = new System.Drawing.Size(134, 25);
            this.BtnSemIvaDolares.TabIndex = 8;
            this.BtnSemIvaDolares.Text = "Total s/ IVA em doláres";
            this.BtnSemIvaDolares.UseVisualStyleBackColor = true;
            this.BtnSemIvaDolares.Click += new System.EventHandler(this.BtnSemIvaDolares_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.BtnSair.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BtnSair.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnSair.Location = new System.Drawing.Point(250, 291);
            this.BtnSair.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(134, 25);
            this.BtnSair.TabIndex = 9;
            this.BtnSair.Text = "Sair";
            this.BtnSair.UseVisualStyleBackColor = true;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(404, 29);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(2);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(85, 17);
            this.radioButton1.TabIndex = 10;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "radioButton1";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(398, 333);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnSemIvaDolares);
            this.Controls.Add(this.BtnComIva);
            this.Controls.Add(this.BtnSemIva);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.lblResultado);
            this.Controls.Add(this.txtPreco);
            this.Controls.Add(this.txtQuantidade);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblTitulo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = "M8 - Exercício 1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtQuantidade;
        private System.Windows.Forms.TextBox txtPreco;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdoFundo;
        private System.Windows.Forms.RadioButton rdoLocalização;
        private System.Windows.Forms.RadioButton rdoAtivar;
        private System.Windows.Forms.RadioButton rdoLegenda;
        private System.Windows.Forms.RadioButton rdoDesativar;
        private System.Windows.Forms.Button BtnSemIva;
        private System.Windows.Forms.Button BtnComIva;
        private System.Windows.Forms.Button BtnSemIvaDolares;
        private System.Windows.Forms.Button BtnSair;
        private System.Windows.Forms.RadioButton radioButton1;
    }
}

