﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prop.Controlos
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMostrarNome_Click(object sender, EventArgs e)
        {

        }

        private void btnLogoUm_Click(object sender, EventArgs e)
        {

        }
    }
}
