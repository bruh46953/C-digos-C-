﻿namespace Prop.Controlos
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTitulo = new System.Windows.Forms.Label();
            this.imgLogos = new System.Windows.Forms.PictureBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.btnMostrarNome = new System.Windows.Forms.Button();
            this.btnMR = new System.Windows.Forms.Button();
            this.btnML = new System.Windows.Forms.Button();
            this.btnAlterarFont = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnAlinharEsq = new System.Windows.Forms.Button();
            this.btnAlinharDir = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnLogoUm = new System.Windows.Forms.Button();
            this.btnLogoDois = new System.Windows.Forms.Button();
            this.lblVoid = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.imgLogos)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitulo
            // 
            this.lblTitulo.BackColor = System.Drawing.Color.RoyalBlue;
            this.lblTitulo.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTitulo.Font = new System.Drawing.Font("Montserrat", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.ForeColor = System.Drawing.Color.AliceBlue;
            this.lblTitulo.Location = new System.Drawing.Point(0, 0);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(611, 50);
            this.lblTitulo.TabIndex = 0;
            this.lblTitulo.Text = "PROPIEDADES DOS CONTROLOS";
            this.lblTitulo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // imgLogos
            // 
            this.imgLogos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.imgLogos.Location = new System.Drawing.Point(13, 66);
            this.imgLogos.Name = "imgLogos";
            this.imgLogos.Size = new System.Drawing.Size(324, 283);
            this.imgLogos.TabIndex = 1;
            this.imgLogos.TabStop = false;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(343, 66);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(253, 25);
            this.lblNome.TabIndex = 2;
            this.lblNome.Text = "INSIRA SEU PRIMEIRO NOME:";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(347, 94);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(252, 20);
            this.txtNome.TabIndex = 3;
            // 
            // btnMostrarNome
            // 
            this.btnMostrarNome.Font = new System.Drawing.Font("Montserrat", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMostrarNome.Location = new System.Drawing.Point(347, 120);
            this.btnMostrarNome.Name = "btnMostrarNome";
            this.btnMostrarNome.Size = new System.Drawing.Size(249, 23);
            this.btnMostrarNome.TabIndex = 4;
            this.btnMostrarNome.Text = "APRESENTAR NOME";
            this.btnMostrarNome.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnMostrarNome.UseVisualStyleBackColor = true;
            this.btnMostrarNome.Click += new System.EventHandler(this.btnMostrarNome_Click);
            // 
            // btnMR
            // 
            this.btnMR.Font = new System.Drawing.Font("Montserrat", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMR.Location = new System.Drawing.Point(347, 149);
            this.btnMR.Name = "btnMR";
            this.btnMR.Size = new System.Drawing.Size(115, 23);
            this.btnMR.TabIndex = 5;
            this.btnMR.Text = "MOVER ->";
            this.btnMR.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnMR.UseVisualStyleBackColor = true;
            // 
            // btnML
            // 
            this.btnML.Font = new System.Drawing.Font("Montserrat", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnML.Location = new System.Drawing.Point(491, 149);
            this.btnML.Name = "btnML";
            this.btnML.Size = new System.Drawing.Size(108, 23);
            this.btnML.TabIndex = 6;
            this.btnML.Text = "<- MOVER";
            this.btnML.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnML.UseVisualStyleBackColor = true;
            // 
            // btnAlterarFont
            // 
            this.btnAlterarFont.Font = new System.Drawing.Font("Montserrat", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlterarFont.Location = new System.Drawing.Point(348, 178);
            this.btnAlterarFont.Name = "btnAlterarFont";
            this.btnAlterarFont.Size = new System.Drawing.Size(115, 23);
            this.btnAlterarFont.TabIndex = 7;
            this.btnAlterarFont.Text = "ALTERAR FONT";
            this.btnAlterarFont.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAlterarFont.UseVisualStyleBackColor = true;
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Montserrat", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(491, 178);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(108, 23);
            this.btnLimpar.TabIndex = 8;
            this.btnLimpar.Text = "LIMPAR";
            this.btnLimpar.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnLimpar.UseVisualStyleBackColor = true;
            // 
            // btnAlinharEsq
            // 
            this.btnAlinharEsq.Font = new System.Drawing.Font("Montserrat", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlinharEsq.Location = new System.Drawing.Point(347, 207);
            this.btnAlinharEsq.Name = "btnAlinharEsq";
            this.btnAlinharEsq.Size = new System.Drawing.Size(150, 23);
            this.btnAlinharEsq.TabIndex = 9;
            this.btnAlinharEsq.Text = "ALINHAR ESQUERDA";
            this.btnAlinharEsq.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAlinharEsq.UseVisualStyleBackColor = true;
            // 
            // btnAlinharDir
            // 
            this.btnAlinharDir.Font = new System.Drawing.Font("Montserrat", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAlinharDir.Location = new System.Drawing.Point(446, 236);
            this.btnAlinharDir.Name = "btnAlinharDir";
            this.btnAlinharDir.Size = new System.Drawing.Size(150, 23);
            this.btnAlinharDir.TabIndex = 10;
            this.btnAlinharDir.Text = "ALINHAR DIREITA";
            this.btnAlinharDir.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnAlinharDir.UseVisualStyleBackColor = true;
            // 
            // btnSair
            // 
            this.btnSair.Font = new System.Drawing.Font("Montserrat", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSair.Location = new System.Drawing.Point(350, 265);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(249, 23);
            this.btnSair.TabIndex = 11;
            this.btnSair.Text = "SAIR";
            this.btnSair.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnSair.UseVisualStyleBackColor = true;
            // 
            // btnLogoUm
            // 
            this.btnLogoUm.Font = new System.Drawing.Font("Montserrat", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogoUm.Location = new System.Drawing.Point(12, 355);
            this.btnLogoUm.Name = "btnLogoUm";
            this.btnLogoUm.Size = new System.Drawing.Size(141, 23);
            this.btnLogoUm.TabIndex = 12;
            this.btnLogoUm.Text = "LOGO 1";
            this.btnLogoUm.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnLogoUm.UseVisualStyleBackColor = true;
            this.btnLogoUm.Click += new System.EventHandler(this.btnLogoUm_Click);
            // 
            // btnLogoDois
            // 
            this.btnLogoDois.Font = new System.Drawing.Font("Montserrat", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogoDois.Location = new System.Drawing.Point(198, 355);
            this.btnLogoDois.Name = "btnLogoDois";
            this.btnLogoDois.Size = new System.Drawing.Size(138, 23);
            this.btnLogoDois.TabIndex = 13;
            this.btnLogoDois.Text = "LOGO 2";
            this.btnLogoDois.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnLogoDois.UseVisualStyleBackColor = true;
            // 
            // lblVoid
            // 
            this.lblVoid.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblVoid.Font = new System.Drawing.Font("Montserrat", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblVoid.Location = new System.Drawing.Point(172, 395);
            this.lblVoid.Name = "lblVoid";
            this.lblVoid.Size = new System.Drawing.Size(291, 36);
            this.lblVoid.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(611, 450);
            this.Controls.Add(this.lblVoid);
            this.Controls.Add(this.btnLogoDois);
            this.Controls.Add(this.btnLogoUm);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnAlinharDir);
            this.Controls.Add(this.btnAlinharEsq);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnAlterarFont);
            this.Controls.Add(this.btnML);
            this.Controls.Add(this.btnMR);
            this.Controls.Add(this.btnMostrarNome);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.imgLogos);
            this.Controls.Add(this.lblTitulo);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.imgLogos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.PictureBox imgLogos;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Button btnMostrarNome;
        private System.Windows.Forms.Button btnMR;
        private System.Windows.Forms.Button btnML;
        private System.Windows.Forms.Button btnAlterarFont;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnAlinharEsq;
        private System.Windows.Forms.Button btnAlinharDir;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnLogoUm;
        private System.Windows.Forms.Button btnLogoDois;
        private System.Windows.Forms.Label lblVoid;
    }
}

